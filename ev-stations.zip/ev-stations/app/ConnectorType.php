<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConnectorType extends Model
{
    //
}
