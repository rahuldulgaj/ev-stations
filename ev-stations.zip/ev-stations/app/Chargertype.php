<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chargertype extends Model
{
    //
}
