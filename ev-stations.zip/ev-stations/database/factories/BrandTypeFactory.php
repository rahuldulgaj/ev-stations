<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BrandType;
use Faker\Generator as Faker;

$factory->define(BrandType::class, function (Faker $faker) {
    return [
        //
    ];
});
