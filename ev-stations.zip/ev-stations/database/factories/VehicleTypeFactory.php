<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VehicleType;
use Faker\Generator as Faker;

$factory->define(VehicleType::class, function (Faker $faker) {
    return [
        //
    ];
});
