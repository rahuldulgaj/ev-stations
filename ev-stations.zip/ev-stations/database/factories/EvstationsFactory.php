<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Evstations;
use Faker\Generator as Faker;

$factory->define(Evstations::class, function (Faker $faker) {
    return [
        //
    ];
});
