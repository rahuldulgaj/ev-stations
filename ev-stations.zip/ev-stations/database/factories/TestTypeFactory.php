<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\TestType;
use Faker\Generator as Faker;

$factory->define(TestType::class, function (Faker $faker) {
    return [
        //
    ];
});
