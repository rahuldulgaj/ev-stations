<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Evstatios;
use Faker\Generator as Faker;

$factory->define(Evstatios::class, function (Faker $faker) {
    return [
        //
    ];
});
