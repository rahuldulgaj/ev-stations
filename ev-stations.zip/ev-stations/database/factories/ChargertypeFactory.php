<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Chargertype;
use Faker\Generator as Faker;

$factory->define(Chargertype::class, function (Faker $faker) {
    return [
        //
    ];
});
